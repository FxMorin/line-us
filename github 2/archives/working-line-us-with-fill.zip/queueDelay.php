<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "Line-Us";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Place, Username FROM Queue ORDER BY Place ASC LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  sleep(4); // sleep for 4 sec
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, "draw.php");
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  curl_exec($ch);
  curl_close($ch);
} else {
  echo "ohh no";
}
?>

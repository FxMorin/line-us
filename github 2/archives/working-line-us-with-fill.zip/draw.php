<?php
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "Line-Us";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT Active FROM GlobalVar";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  // output data of each row
  $row = $result->fetch_assoc();
  if ($row["Active"] == 1) {$conn->close();die("Already Running!!");}
}
function sqlProcess($conn, $process) {
  $sql = "UPDATE GlobalVar SET Process='".$process."'";
  if ($conn->query($sql) === TRUE) {
    //echo "Record updated successfully\n";
  } else {
    //echo "Error updating record: " . $conn->error;
  }
}
function Active($conn, $stat) {
  $sql = "UPDATE GlobalVar SET Active='".$stat."'";
  if ($conn->query($sql) === TRUE) {
    //echo "Record updated successfully\n";
  } else {
    //echo "Error updating record: " . $conn->error;
  }
}
function perc($count, $amount) {
  return (($count/$amount)*100);
}
function logger($logs) {
    ignore_user_abort(true);
    $fh = fopen('/Applications/XAMPP/xamppfiles/htdocs/logs.txt','a');
    fclose($fh);
    sleep(1);
    file_put_contents("/Applications/XAMPP/xamppfiles/htdocs/logs.txt",$logs, FILE_APPEND | LOCK_EX);
    ignore_user_abort(false);
}
function putIp($conn, $ip) {
    $sql = "UPDATE GlobalVar SET ip='".$ip."'";
    if ($conn->query($sql) === TRUE) {
    //echo "Record updated successfully\n";
    } else {
    //echo "Error updating record: " . $conn->error;
    }
}
function getIp($conn) {
    $sql = "SELECT ip FROM GlobalVar";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
    // output data of each row
    $row = $result->fetch_assoc();
    return $row['ip'];
  }
}
function get_hello_message($client) {
  $line = "";
  while (true) {
    $data = stream_get_contents($client, 1);
    if ($data == "\0") {
      break;
    } else {
      $line .= $data;
    }
  }
  //logger($line);
  return $line;
}
function getBotIp($conn) {
  $ip = "";
  ignore_user_abort(true);     ## prevent refresh from aborting file operations and hosing file
  if (getIp($conn) != "") {
    $ip = getIp($conn);
    $connection = @fsockopen($ip, $port, $errno, $errstr, 0.8);
    if (is_resource($connection)) {
      fclose($connection);
      return $ip;
    }
  }
  $counter = 0;
  $port = "1337";
  while ($counter <= 254) {
    $connection = @fsockopen("192.168.0.".$counter, $port, $errno, $errstr, 0.5);
    if (is_resource($connection)) {
      fclose($connection);
      $ip = "192.168.0.".$counter;
      putIp($conn, $ip);
      break;
    }
    $counter++;
  }
ignore_user_abort(false);
return $ip;
}
function readOutput($client) {
  $line = "";
  while (true) {
    $data = stream_get_contents($client, 1);
    if ($data == "\0" || $data == "\x00" || $data == "\x0") {
      break;
    } else {
      $line .= $data;
    }
  }
  return $line;
}
###################
## START OF MAIN ##
###################
function start($conn) {
$gcode = "";
$output = "";
$count = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $sql = "SELECT Place, GCode FROM Queue ORDER BY Place ASC LIMIT 1";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    // output data of each row
    $row = $result->fetch_assoc();
    $gcode = $row['GCode'];

    $sql = "DELETE FROM Queue WHERE Place='".$row['Place']."'";
    if ($conn->query($sql) === TRUE) {
      echo "Record deleted successfully";
    } else {
      echo "Error deleting record: " . $conn->error;
    }
  } else {
    Active($conn, 0);
    $conn->close();
    exit;
  }
  Active($conn, 1);
  $addr = getBotIp($conn);
  if ($addr == "") {
    Active($conn, 0);
    $conn->close();
    die("Unable to find line-us bot!");
  }
  $port = "1337";
  $client = @stream_socket_client("tcp://$addr:$port", $errno, $errorMessage);
  if($client === false){
    Active($conn, 0);
    $conn->close();
    die("Unable to communicate to bot!");
  }
  $gcode .= "\0";
  $gcode = str_replace("\n","\0\r",$gcode);
  $array = explode( "\r", $gcode );
  $lines = SplFixedArray::fromArray($array);
  unset( $array );
  //$lines = explode( "\r", $gcode );
  $output .= get_hello_message($client)."\n\n";
  foreach ($lines as $line) {
    $count++;
    sqlProcess($conn, perc($count,count($lines)));
    //logger(perc($count,count($lines))."\n");
    fwrite($client, $line);
    //logger($line);
    $output .= readOutput($client)."\n";
    sleep(0.05);
  }
  //logger("G28");
  //fwrite($client, "\0");
  //logger("\0");
  fclose($client);
  $output .= "\n\nDONE!\n\n";
  sleep(2);
  start($conn);
}
}
start($conn);
?>

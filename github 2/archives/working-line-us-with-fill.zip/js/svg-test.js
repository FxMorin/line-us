var theSvg = SVG("svgHere").attr({id:"draw",style:"visibility:hidden"});
function editor(){
  var text = document.getElementById("edit").value;
  var coolCode = document.getElementById("finalCode");
  var poop = document.getElementById("coolCode");
  //poop.innerHTML = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  var killerPoop = poop.querySelectorAll("svg");
  killerPoop[0].innerHTML = "";
  coolCode.innerHTML = text;
  var killer2 = coolCode.querySelectorAll("svg");
  if (killer2[0]) {
    var killer = killer2[0].querySelectorAll("path");
    for (var p = 0; p < killer.length; p++){
      var draw = theSvg.path(killer[p].attributes.d.value).array();
      var newPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
      newPath.setAttribute('d', svgGcode2(draw.value));
      newPath.setAttribute('stroke', "black");
      newPath.setAttribute('fill', "transparent");
      killerPoop[0].appendChild(newPath);
    }
  }
}

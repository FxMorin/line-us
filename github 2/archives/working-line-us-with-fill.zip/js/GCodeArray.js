function GCodeVars(gcode) {
  var setX = false;
  var setY = false;
  var lowX = 0;
  var lowY = 0;
  var highX = 0;
  var highY = 0;
  var tmp = "";
  var loopX = false;
  var loopY = false;
  for (var y = 0; y < gcode.length; y++) {
    if (loopX) {
      if (gcode.charAt(y) != " ") {
        tmp += gcode.charAt(y);
      } else {
        if (setX != true) {
          highX = parseInt(tmp);
          lowX = parseInt(tmp);
          setX = true;
        } else {
          if (parseInt(tmp) > highX) {
            highX = parseInt(tmp);
          } else if (parseInt(tmp) < lowX) {
            lowX = parseInt(tmp);
          }
        }
        tmp = "";
        loopX = false;
        loopY = false;
      }
    }
    if (loopY) {
      if (gcode.charAt(y) != " ") {
        tmp += gcode.charAt(y);
      } else {
        if (setY != true) {
          highY = parseInt(tmp);
          lowY = parseInt(tmp);
          setY = true;
        } else {
          if (parseInt(tmp) > highY) {
            highY = parseInt(tmp);
          } else if (parseInt(tmp) < lowY) {
            lowY = parseInt(tmp);
          }
        }
        tmp = "";
        loopY = false;
        loopX = false;
      }
    }
    if (gcode.charAt(y) == "X") {
      loopX = true;
    } else if (gcode.charAt(y) == "Y") {
      loopY = true;
    }
  }
  var validate = highX + " " + lowX + " " + highY + " " + lowY;
  return validate.split(" ");
}

var slabScale = 10;
var bitWidth = 2;
var newline = "\n";
var svg3 = "";
var lastL = "";
var ControlPointX = 0;
var ControlPointY = 0;
var moreX = 0;
var moreY = 0;
var first = true;
var tmpWord;
var theSvg2;
var secondary = false;
var lastIn = false;
var offset = Math.round((bitWidth * slabScale) / 2);

function svgGcode3(canvas, svg) {
	console.log(svg);
	var ctx=canvas.getContext("2d");
	var svgStatment = document.createElement("svg");
	svgStatment.id = "PLS" + $("#crick > div").length+1;
	document.getElementById("crick").appendChild(svgStatment);
	theSvg2 = SVG(svgStatment.id).attr({id:"draw-" + svgStatment.id,style:"visibility:hidden"});
	var draw = theSvg2.path(svg.attributes.d.value).array();
	var thePaths1 = draw.value;
	for (var i = 0; i < thePaths1.length; i++) {
		switch(thePaths1[i][0]) {
    	case "M" || "m":
        svgM4(ctx,thePaths1, i);
        break;
    	case "L" || "l":
        svgL4(ctx,thePaths1, i);
        break;
			case "H" || "h":
	      svgH4(ctx,thePaths1, i);
	      break;
			case "V" || "v":
				svgV4(ctx,thePaths1, i);
				break;
			case "C" || "c":
				svgC4(ctx,thePaths1, i);
				break;
			case "S" || "s":
				svgS4(ctx,thePaths1, i);
				break;
			case "Q" || "q":
				svgQ4(ctx,thePaths1, i);
				break;
			case "T" || "t":
				svgT4(ctx,thePaths1, i);
				break;
			case "A" || "a":
				svgA4(ctx,thePaths1, i);
				break;
			case "Z" || "z":
				return svgZ4(ctx, canvas, thePaths1, i, theSvg2);
				break;
    	default:
        break;
		}
	}
}
function PointXY(xx, yy) {
    this.coolX = xx;
    this.coolY = yy;
}
function Point(xx, yy) {
    this.x = xx;
    this.y = yy;
}
function svgM4(ctx,thePaths1, i) {
	moreX = thePaths1[i][1];
	moreY = thePaths1[i][2];
	lastL = "M";
	fastMove3(ctx,thePaths1[i][1],thePaths1[i][2]);
}
function svgL4(ctx,thePaths1, i) {
	moreX = thePaths1[i][1];
	moreY = thePaths1[i][2];
	lastL = "L";
	slowMove3(ctx,thePaths1[i][1],thePaths1[i][2]);
}
function svgH4(ctx,thePaths1, i) {
	moreX = thePaths1[i][1];
	lastL = "H";
	slowMove3(ctx,thePaths1[i][1],moreY);
}
function svgV4(ctx,thePaths1, i) {
	moreY = thePaths1[i][1];
	lastL = "V";
	slowMove3(ctx,moreX, thePaths1[i][1]);
}
function svgC4(ctx,thePaths1, i) {
	var point1 = new PointXY(moreX,moreY);
	var handle1 = new Point(thePaths1[i][1],thePaths1[i][2]);
	var handle2 = new Point(thePaths1[i][3],thePaths1[i][4]);
	var point2 = new Point(thePaths1[i][5],thePaths1[i][6]);
	var bezierLength = Bezier(point1, handle1, handle2,point2);
	//var bezierAmount = 10;
	var bezierAmount = bezierLength / (bezierLength / 18);
	var bezierPoint = bezierLength / bezierAmount;
	var points = [];
	var q;
	for (q = 0; q <= bezierAmount; q++) {
		var bezierP = BezierP(point1, handle1, handle2,point2,bezierPoint*q);
		slowMove3(ctx,bezierP.moreX, bezierP.moreY);
	}
	lastL = "C";
	moreX = thePaths1[i][5];
	moreY = thePaths1[i][6];
}
function svgS4(ctx,thePaths1, i) {
	if (thePaths1[i][1] > moreX) {
		if (thePaths1[i][2] > moreY) {
			slowMove3(ctx,thePaths1[i][1], moreY+(thePaths1[i][2]-moreY)/2);
			slowMove3(ctx,thePaths1[i][3]-(moreX+(thePaths1[i][1]-moreX)), moreY+(thePaths1[i][2]-moreY)/2);
			slowMove3(ctx,thePaths1[i][3], thePaths1[i][4]);
		} else {
			slowMove3(ctx,thePaths1[i][1], thePaths1[i][2]+(moreY-thePaths1[i][2])/2);
			slowMove3(ctx,thePaths1[i][3]-(moreX+(thePaths1[i][1]-moreX)), moreY+(thePaths1[i][2]-moreY)/2);
			slowMove3(ctx,thePaths1[i][3], thePaths1[i][4]);
		}
	} else {
		if (thePaths1[i][2] > moreY) {
			slowMove3(ctx,thePaths1[i][1], moreY+(thePaths1[i][2]-moreY)/2);
			slowMove3(ctx,thePaths1[i][3]-(thePaths1[i][1]+(moreX-thePaths1[i][1])), moreY+(thePaths1[i][2]-moreY)/2);
			slowMove3(ctx,thePaths1[i][3], thePaths1[i][4]);
		} else {
			slowMove3(ctx,thePaths1[i][1], thePaths1[i][2]+(moreY-thePaths1[i][2])/2);
			slowMove3(ctx,thePaths1[i][3]-(moreX-thePaths1[i][1]), moreY+(thePaths1[i][2]-moreY)/2);
			slowMove3(ctx,thePaths1[i][3], thePaths1[i][4]);
		}
	}
	lastL = "S";
	moreX = thePaths1[i][3];
	moreY = thePaths1[i][4];
}
function svgQ4(ctx,thePaths1, i) {
	var point1 = new PointXY(moreX,moreY);
	var handle1 = new Point(thePaths1[i][1],thePaths1[i][2]);
	var handle2 = new Point(thePaths1[i][3],thePaths1[i][4]);
	var bezierLength = Quadratic(point1, handle1, handle2);
	//var bezierAmount = 10;
	var bezierAmount = bezierLength / (bezierLength / 18);
	var bezierPoint = bezierLength / bezierAmount;
	var points = [];
	var k;
	for (k = 1; k <= bezierAmount; k++) {
		var bezierP = QuadraticP(point1, handle1, handle2,bezierPoint*k);
		slowMove3(ctx,bezierP.x, bezierP.y);
	}
	lastL = "Q";
	moreX = thePaths1[i][3];
	moreY = thePaths1[i][4];
}
function svgT4(ctx,ctx,thePaths1, i) {
	if (lastL == "Q") {
		if (ControlPointY > moreY) {
			slowMove3(ctx,ControlPointX, moreY-(ControlPointY-moreY));
			slowMove3(ctx,thePaths1[i][1], thePaths1[i][2]);
		} else {
			slowMove3(ctx,ControlPointX, ControlPointY-(moreY-ControlPointY));
			slowMove3(ctx,thePaths1[i][1], thePaths1[i][2]);
		}
	} else {
		slowMove3(ctx,thePaths1[i][1], thePaths1[i][2]);
	}
	lastL = "T";
	moreX = thePaths1[i][1];
	moreY = thePaths1[i][2];
}
function svgA4(ctx,thePaths1, i) {
	lastL = "A";
	moreX = thePaths1[i][6];
	moreY = thePaths1[i][7];
	slowMove3(ctx,thePaths1[i][6], thePaths1[i][7]);  //W.I.P.
}
function svgZ4(ctx, canvas, thePaths1, i, theSvg2) {
	lastL = "Z";
	return raiseBit3(ctx, canvas, theSvg2);
}

function check(thePaths1, i, num){
	if (thePaths1[i].length < num) {
		return true;
	} else {
		console.log("too long");
		return false;
	}
}



function raiseBit3(ctx, canvas, theSvg2) {
	ctx.strokeStyle="black";
	var yy = 0;
	var xx = 0;
	var startX = [];
  var startY = [];
  var endX = [];
  var endY = [];
	/*LoopYY:
	for (yy = canvas.height; yy >= 0; yy) {
		lastIn = false;
		//LoopXX:
    for (xx = 0; xx <= canvas.width; xx++) {
      //var el = ctx.isPointInPath(xx, yy);
      //console.log("start: " + el);
      //if (el == true) {
				//if (secondary == false) {
					LoopOther:
        	for (f = 1; f <= canvas.width; f++) {
          	var ell = ctx.isPointInPath(xx+(f), yy+(f));
          	if (ell == true) {
							//if (lastIn == true) {
								if (startX[count] == null) {
									startX[count] = xx+f;
									startY[count] = yy;
								}
            		endX[count] = startX[count]+(f);
            		endY[count] = startY[count]+(f);
								ctx.moveTo(startX[count],startY[count]);
								ctx.lineTo(endX[count],endY[count]);
								console.log("f: " + f);
								//count++;
            		console.log("count: " + count);
								//lastIn = false;
            		break LoopOther;
							}
          	}
							count++;
							//lastIn = true;
						}
        	//}
					//secondary = true;
      	//}
			//} //else {
				//secondary = false;
			//}
    //}
		yy = yy - 10;
  }*/
	var wasIn = false;
	var firstHit = true;
	var count = 0;
	for (yy = -50; yy <= canvas.height+50; yy = yy + 20) {
		for (f = 0; f <= canvas.height; f++) {
			if (ctx.isPointInPath(f,Math.floor(f/20)+yy, "evenodd")) {
				if (firstHit) {
					startX[count] = f;
					startY[count] = Math.floor(f/20)+yy;
					firstHit = false;
					wasIn = true;
				}
				//ctx.fillRect(f, Math.floor(f/10)+yy,1,1);
			} else {
				if (wasIn) {
					endX[count] = f;
					endY[count] = Math.floor(f/20)+yy;
					ctx.moveTo(startX[count],startY[count]);
					ctx.lineTo(endX[count],endY[count]);
					count++
					wasIn = false;
					firstHit = true;
				}
			}
		}
	}
	/*for (yy = 0; yy <= canvas.height; yy += 10) {
		for (xx = 0; xx <= canvas.width; xx++) {
			slowCircle(ctx, yy+xx/4, xx)
		}
	}*/
	var yello = document.createElementNS("http://www.w3.org/2000/svg", "path");
  var pencil = "";
  for (f = 0; f < count; f++) {
		//if (startX[f] == null || startY[f] == null) {break;}
    pencil += " M " + startX[f] + " " + startY[f] + " L " + startX[f] + " " + startY[f] + " L " + endX[f] + " " + endY[f];
  }
	yello.setAttribute('fill', 'rgb(0,0,0)');
	yello.setAttribute('stroke', 'rgb(0,0,0)');
	pencil = pencil.substring(1) + " Z";
  yello.setAttribute('d', pencil);
	document.getElementById("SvgjsSvg1001").style = "";
	document.getElementById("SvgjsSvg1001").style.width = 500;
	document.getElementById("SvgjsSvg1001").style.height = 500;
	document.getElementById("SvgjsSvg1001").appendChild(yello);
	document.getElementById("bestCode").appendChild(document.getElementById("SvgjsSvg1001"));
  ctx.stroke();
  return pencil;
}
function fastMove3(ctx, moreX, moreY) {
	ctx.beginPath();
	ctx.moveTo(moreX,moreY);
}
function slowMove3(ctx, moreX, moreY) {
	ctx.lineTo(moreX,moreY);
}
function slowCircle(ctx, moreX, moreY) {
	ctx.ellipse(moreX, moreY, 1, 1, 0, 0, 360);
}

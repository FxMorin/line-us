function fill(svg) {
  path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  canvas = document.getElementById("theTrueCanvas");
  displayClassySVG = document.getElementById("bestCode");
  path.setAttribute('d', svg);
  path.setAttribute('fill', "rgb(0,0,0)");
  canvas.height = 500;
  canvas.width = 500;
  displayClassySVG.height = 500;
  displayClassySVG.width = 500;
  var ctx = svgGcode3(canvas, path);
  /*var xx;
  var yy;
  var startX = [];
  var startY = [];
  var endX = [];
  var endY = [];
  var count = 1;
  console.log(ctx)
  for (yy = 0; yy <= canvas.height; yy += 12) {
    for (xx = 0; xx <= canvas.width; xx++) {
      var el = ctx.isPointInPath(xx, yy);
      console.log(el);
      if (el == true) {
        console.log("XX: " + xx);
        console.log("YY: " + yy);
        startX[count] = xx;
        startY[count] = yy;
        console.log(canvas.width-xx);
        for (f = 1; f <= canvas.width-xx; f++) {
          console.log(f);
          console.log((xx+f*2) + " " + (yy+f*8));
          var el = ctx.isPointInPath(xx+f*2, yy+f*8);
          if (el == true) {
            endX[count] = xx+(f-1)*2;
            endY[count] = yy+(f-1)*8;
            count++;
            console.log(count++)
            break;
          }
        }
        break;
      }
    }
  }
  yello = document.createElementNS("http://www.w3.org/2000/svg", "path");
  var pencil = "";
  for (f = 1; f < count; f++) {
    pencil += " M " + startX[f] + " " + startY[f] + " L " + endX[f] + " " + endY[f] + " Z ";
    console.log(startX[f] + " " + startY[f] + " " + endX[f] + " " + endY[f]);
  }
  yello.setAttribute('d', pencil);
  console.log(yello);
  ctx.stroke();
  return pencil;*/
  return ctx;
}

<?php

// Cron Job Engine
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Line-Us";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT Cron FROM GlobalVar";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  // output data of each row
  $row = $result->fetch_assoc();
  if ($row["Cron"]) {exit;}
}
$conn->close();
ignore_user_abort(true);
while(true)
{
    sleep(60); // sleep for 60 sec = 1 minute

    $s = curl_init();
    curl_setopt($s,CURLOPT_URL, 'draw.php');
    curl_exec($s);
    curl_getinfo($s,CURLINFO_HTTP_CODE);
    curl_close($s);
}
?>

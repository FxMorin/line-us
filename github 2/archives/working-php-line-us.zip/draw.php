<?php
$output = "";
function logger($logs) {
    //ignore_user_abort(true);
    //$fh = fopen('/Applications/XAMPP/xamppfiles/htdocs/logs.txt','a');
    //fclose($fh);
    //sleep(1);
    //file_put_contents("/Applications/XAMPP/xamppfiles/htdocs/logs.txt",$logs, FILE_APPEND | LOCK_EX);
    //ignore_user_abort(false);
}
function putIp($ip) {
    ignore_user_abort(true);
    $fh = fopen('/Applications/XAMPP/xamppfiles/htdocs/theData.txt','w');
    fclose($fh);
    sleep(1);
    file_put_contents("/Applications/XAMPP/xamppfiles/htdocs/theData.txt",$ip);
    ignore_user_abort(false);
}
function getIp() {
    ignore_user_abort(true);
    $fh = fopen('/Applications/XAMPP/xamppfiles/htdocs/theData.txt','a');
    fclose($fh);
    sleep(1);
    $ip = file_get_contents("/Applications/XAMPP/xamppfiles/htdocs/theData.txt");
    ignore_user_abort(false);
    return $ip;
}
function get_hello_message($client) {
  $line = "";
  while (true) {
    $data = stream_get_contents($client, 1);
    if ($data == "\0") {
      break;
    } else {
      $line .= $data;
    }
  }
  return $line;
}
function getBotIp() {
  $ip = "";
  ignore_user_abort(true);     ## prevent refresh from aborting file operations and hosing file
  if (getIp() != "") {
    $ip = getIp();
    $connection = @fsockopen($ip, $port, $errno, $errstr, 0.8);
    if (is_resource($connection)) {
      fclose($connection);
      return $ip;
    }
  }
  $counter = 0;
  $port = "1337";
  while ($counter <= 254) {
    $connection = @fsockopen("192.168.0.".$counter, $port, $errno, $errstr, 0.5);
    if (is_resource($connection)) {
      fclose($connection);
      $ip = "192.168.0.".$counter;
      putIp($ip);
      break;
    }
    $counter++;
  }
ignore_user_abort(false);
return $ip;
}
function readOutput($client) {
  $line = "";
  while (true) {
    $data = stream_get_contents($client, 1);
    if ($data == "\0" || $data == "\x00" || $data == "") {
      break;
    } else {
      $line .= $data;
    }
  }
  return $line;
}
###################
## START OF MAIN ##
###################
if (isset($_POST['gcode'])) {
  $gcode = $_POST['gcode'];
  $addr = getBotIp();
  if ($addr == "") {
    die("Unable to find line-us bot!");
  }
  $port = "1337";
  $client = @stream_socket_client("tcp://$addr:$port", $errno, $errorMessage);
  if($client === false){
    die("Unable to communicate to bot!");
  }
  $gcode = str_replace("\n","\0\r",$gcode);
  $lines = explode( "\r", $gcode );
  $output .= get_hello_message($client)."\n\n";
  sleep(1);
  foreach ($lines as $line) {
    if (connection_aborted()){break;}
    fwrite($client, $line);
    logger($line);
    $output .= readOutput($client)."\n";
  }
  fwrite($client, "G28");
  logger("G28");
  fwrite($client, "\0");
  logger("\0");
  sleep(0.5);
  fclose($client);
  $output .= "\n\nDONE!\n";
  logger($output);
} else {
  die("Unable to get image data!");
}
?>

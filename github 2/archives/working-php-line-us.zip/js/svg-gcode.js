var slabScale = 10;
var bitWidth = 2;
var newline = "\n";
var svg = "";
var lastL = "";
var ControlPointX = 0;
var ControlPointY = 0;
var coolX = 0;
var coolY = 0;
var tmpWord;
var first = false;
var offset = Math.round((bitWidth * slabScale) / 2);

function svgGcode2(almostBetter, thePaths) {
	for (var i = 0; i < thePaths.length; i++) {
		switch(thePaths[i][0]) {
    	case "M" || "m":
        svg += svgM(thePaths, i);
        break;
    	case "L" || "l":
        svg += svgL(thePaths, i);
        break;
			case "H" || "h":
	      svg += svgH(thePaths, i);
	      break;
			case "V" || "v":
				svg += svgV(thePaths, i);
				break;
			case "C" || "c":
				svg += svgC(thePaths, i);
				break;
			case "S" || "s":
				svg += svgS(thePaths, i);
				break;
			case "Q" || "q":
				svg += svgQ(thePaths, i);
				break;
			case "T" || "t":
				svg += svgT(thePaths, i);
				break;
			case "A" || "a":
				svg += svgA(thePaths, i);
				break;
			case "Z" || "z":
				svg += svgZ(thePaths, i);
				break;
    	default:
        break;
		}
		if (0 == i % 2) {
			var newPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
			newPath.setAttribute('d', svg);
			svg = "";
			var hue = 'rgb(' + (Math.floor(Math.random() * 256)) + ',' + (Math.floor(Math.random() * 256)) + ',' + (Math.floor(Math.random() * 256)) + ')';
			newPath.setAttribute('stroke', hue);
			newPath.setAttribute('fill', "transparent");
			almostBetter[0].appendChild(newPath);
			raiseBit2();
			svg += fastMove2(coolX,coolY);
		}
	}
	first = false;
	return svg;
}
function PointXY(xx, yy) {
    this.coolX = xx;
    this.coolY = yy;
}
function Point(xx, yy) {
    this.x = xx;
    this.y = yy;
}
function svgM(thePaths, i) {
	coolX = thePaths[i][1];
	coolY = thePaths[i][2];
	lastL = "M";
	return fastMove2(thePaths[i][1],thePaths[i][2]);
}
function svgL(thePaths, i) {
	coolX = thePaths[i][1];
	coolY = thePaths[i][2];
	lastL = "L";
	return slowMove2(thePaths[i][1],thePaths[i][2]);
}
function svgH(thePaths, i) {
	coolX = thePaths[i][1];
	lastL = "H";
	return slowMove2(thePaths[i][1],coolY);
}
function svgV(thePaths, i) {
	coolY = thePaths[i][1];
	lastL = "V";
	return slowMove2(coolX, thePaths[i][1]);
}
function svgC(thePaths, i) {
	var point1 = new PointXY(coolX,coolY);
	var handle1 = new Point(thePaths[i][1],thePaths[i][2]);
	var handle2 = new Point(thePaths[i][3],thePaths[i][4]);
	var point2 = new Point(thePaths[i][5],thePaths[i][6]);
	var bezierLength = Bezier(point1, handle1, handle2,point2);
	//var bezierAmount = 10;
	var bezierAmount = bezierLength / (bezierLength / 18);
	var bezierPoint = bezierLength / bezierAmount;
	var points = [];
	var tmpWord = "";
	var q;
	for (q = 0; q <= bezierAmount; q++) {
		var bezierP = BezierP(point1, handle1, handle2,point2,bezierPoint*q);
		tmpWord += slowMove2(bezierP.coolX, bezierP.coolY);
	}
	lastL = "C";
	coolX = thePaths[i][5];
	coolY = thePaths[i][6];
	return tmpWord;
}
function svgS(thePaths, i) {
	if (thePaths[i][1] > coolX) {
		if (thePaths[i][2] > coolY) {
			tmpWord = slowMove2(thePaths[i][1], coolY+(thePaths[i][2]-coolY)/2);
			tmpWord += slowMove2(thePaths[i][3]-(coolX+(thePaths[i][1]-coolX)), coolY+(thePaths[i][2]-coolY)/2);
			tmpWord += slowMove2(thePaths[i][3], thePaths[i][4]);
		} else {
			tmpWord = slowMove2(thePaths[i][1], thePaths[i][2]+(coolY-thePaths[i][2])/2);
			tmpWord += slowMove2(thePaths[i][3]-(coolX+(thePaths[i][1]-coolX)), coolY+(thePaths[i][2]-coolY)/2);
			tmpWord += slowMove2(thePaths[i][3], thePaths[i][4]);
		}
	} else {
		if (thePaths[i][2] > coolY) {
			tmpWord = slowMove2(thePaths[i][1], coolY+(thePaths[i][2]-coolY)/2);
			tmpWord += slowMove2(thePaths[i][3]-(thePaths[i][1]+(coolX-thePaths[i][1])), coolY+(thePaths[i][2]-coolY)/2);
			tmpWord += slowMove2(thePaths[i][3], thePaths[i][4]);
		} else {
			tmpWord = slowMove2(thePaths[i][1], thePaths[i][2]+(coolY-thePaths[i][2])/2);
			tmpWord += slowMove2(thePaths[i][3]-(coolX-thePaths[i][1]), coolY+(thePaths[i][2]-coolY)/2);
			tmpWord += slowMove2(thePaths[i][3], thePaths[i][4]);
		}
	}
	lastL = "S";
	coolX = thePaths[i][3];
	coolY = thePaths[i][4];
	return tmpWord;
}
function svgQ(thePaths, i) {
	var point1 = new PointXY(coolX,coolY);
	var handle1 = new Point(thePaths[i][1],thePaths[i][2]);
	var handle2 = new Point(thePaths[i][3],thePaths[i][4]);
	var bezierLength = Quadratic(point1, handle1, handle2);
	//var bezierAmount = 10;
	var bezierAmount = bezierLength / (bezierLength / 18);
	var bezierPoint = bezierLength / bezierAmount;
	var points = [];
	var tmpWord = "";
	var k;
	for (k = 1; k <= bezierAmount; k++) {
		var bezierP = QuadraticP(point1, handle1, handle2,bezierPoint*k);
		tmpWord += slowMove2(bezierP.x, bezierP.y);
	}
	lastL = "Q";
	coolX = thePaths[i][3];
	coolY = thePaths[i][4];
	return tmpWord;
}
function svgT(thePaths, i) {
	if (lastL == "Q") {
		if (ControlPointY > coolY) {
			tmpWord = slowMove2(ControlPointX, coolY-(ControlPointY-coolY));
			tmpWord += slowMove2(thePaths[i][1], thePaths[i][2]);
		} else {
			tmpWord = slowMove2(ControlPointX, ControlPointY-(coolY-ControlPointY));
			tmpWord += slowMove2(thePaths[i][1], thePaths[i][2]);
		}
	} else {
		tmpWord = slowMove2(thePaths[i][1], thePaths[i][2]);
	}
	lastL = "T";
	coolX = thePaths[i][1];
	coolY = thePaths[i][2];
	return tmpWord;
}
function svgA(thePaths, i) {
	lastL = "A";
	coolX = thePaths[i][6];
	coolY = thePaths[i][7];
	return slowMove2(thePaths[i][6], thePaths[i][7]);  //W.I.P.
}
function svgZ(thePaths, i) {
	lastL = "Z";
	return raiseBit2();
}

function check(thePaths, i, num){
	if (thePaths[i].length < num) {
		return true;
	} else {
		console.log("too long");
		return false;
	}
}



function raiseBit2() {
	return " Z ";
}
function fastMove2(coolX, coolY) {
	if (first == false) {
		return "M " + coolX + " " + coolY;
		first = true;
	} else {
		return " M " + coolX + " " + coolY;
	}
}
function slowMove2(coolX, coolY) {
	return " L " + Math.round(coolX,2) + " " + Math.round(coolY,2);
}

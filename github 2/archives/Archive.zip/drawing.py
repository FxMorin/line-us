import socket
import time
import sys
firstRun = sys.argv[0]


class LineUs:
    """An example class to show how to use the Line-us API"""

    def __init__(self, line_us_name):
        self.__line_us = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.__line_us.connect((line_us_name, 1337))
        self.__connected = True
        self.__hello_message = self.__read_response()

    def get_hello_string(self):
        if self.__connected:
            return self.__hello_message.decode()
        else:
            return 'Not connected'

    def disconnect(self):
        """Close the connection to the Line-us"""
        self.__line_us.close()
        self.__connected = False

    def custom(self, cmds):
        """just run a gcode command"""
        cmd = str(cmds).encode()
        self.__send_command(cmd)
        return self.__read_response()

    def __read_response(self):
        """Read form the socket one byte at a time until we get a null"""
        line = b''
        while True:
            char = self.__line_us.recv(1)
            if char != b'\x00':
                line += char
            elif char == b'\x00':
                break
        return line

    def __send_command(self, command):
        """Send the command to Line-us"""
        command += b'\x00'
        self.__line_us.send(command)

my_line_us = LineUs('192.168.0.46')
print(my_line_us.get_hello_string())
time.sleep(1)
for line in firstRun.splitlines():
    print(my_line_us.custom(line))
print("DONE")


time.sleep(1)
my_line_us.disconnect()

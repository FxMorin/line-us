var slabScale = 10;
var bitWidth = 2;
var plungeRate = 1000;
var newline = "\n";
var gcode = "";
var lastL = "";
var ControlPointX = 0;
var ControlPointY = 0;
var x = 0;
var y = 0;
var tmpWord;
var offset = Math.round((bitWidth * slabScale) / 2);

function svgGcode(thePath) {
	for (var i = 0; i < thePath.length; i++) {
		switch(thePath[i][0]) {
    	case "M" || "m":
        gcode += svgM(thePath, i);
        break;
    	case "L" || "l":
        gcode += svgL(thePath, i);
        break;
			case "H" || "h":
	      gcode += svgH(thePath, i);
	      break;
			case "V" || "v":
				gcode += svgV(thePath, i);
				break;
			case "C" || "c":
				gcode += svgC(thePath, i);
				break;
			case "S" || "s":
				gcode += svgS(thePath, i);
				break;
			case "Q" || "q":
				gcode += svgQ(thePath, i);
				break;
			case "T" || "t":
				gcode += svgT(thePath, i);
				break;
			case "A" || "a":
				gcode += svgA(thePath, i);
				break;
			case "Z" || "z":
				gcode += svgZ(thePath, i);
				break;
    	default:
        break;
		}
	}
	return gcode;
}
function svgM(thePath, i) {
	lastL = "M";
	x = thePath[i][1];
	y = thePath[i][2];
	return fastMove(thePath[i][1],thePath[i][2]);
}
function svgL(thePath, i) {
	lastL = "L";
	x = thePath[i][1];
	y = thePath[i][2];
	return slowMove(thePath[i][1],thePath[i][2]);
}
function svgH(thePath, i) {
	lastL = "H";
	x = thePath[i][1];
	return slowMove(thePath[i][1],y);
}
function svgV(thePath, i) {
	lastL = "V";
	y = thePath[i][1];
	return slowMove(x, thePath[i][1]);
}
function svgC(thePath, i) {
	lastL = "C";
	if ((thePath[i][1] <= x && thePath[i][3] >= thePath[i][5]) && ((x > thePath[i][5]) || ((thePath[i][1] >= x && thePath[i][3] <= thePath[i][5]) && x < thePath[i][5]))) {
		if (thePath[i][2] > y) {
			tmpWord = slowMove(thePath[i][1], y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3], y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][5], thePath[i][6]);
		} else {
			tmpWord = slowMove(thePath[i][1], thePath[i][2]+(y-thePath[i][2])/2);
			tmpWord += slowMove(thePath[i][3], thePath[i][2]+(y-thePath[i][2])/2);
			tmpWord += slowMove(thePath[i][5], thePath[i][6]);
		}
	} else {
		if (thePath[i][2] > y) {
			if (thePath[i][5] > x) {
				tmpWord = slowMove(x+((thePath[i][5]-x)/4)*1, y+(thePath[i][2]-y)/2.3);
				tmpWord += slowMove(x+((thePath[i][5]-x)/4)*2, y+(thePath[i][2]-y)/2);
				tmpWord += slowMove(x+((thePath[i][5]-x)/4)*3, y+(thePath[i][2]-y)/2.3);
				tmpWord += slowMove(thePath[i][5], thePath[i][6]);
			} else {
				tmpWord = slowMove(thePath[i][5]+((x-thePath[i][5])/4)*1, y+(thePath[i][2]-y)/2.3);
				tmpWord += slowMove(thePath[i][5]+((x-thePath[i][5])/4)*2, y+(thePath[i][2]-y)/2);
				tmpWord += slowMove(thePath[i][5]+((x-thePath[i][5])/4)*3, y+(thePath[i][2]-y)/2.3);
				tmpWord += slowMove(thePath[i][5], thePath[i][6]);
			}
		} else {
			if (thePath[i][5] > x) {
				tmpWord = slowMove(x+((thePath[i][5]-x)/4)*1, thePath[i][2]+(y-thePath[i][2])/2.3);
				tmpWord += slowMove(x+((thePath[i][5]-x)/4)*2, thePath[i][2]+(y-thePath[i][2])/2);
				tmpWord += slowMove(x+((thePath[i][5]-x)/4)*3, thePath[i][2]+(y-thePath[i][2])/2.3);
				tmpWord += slowMove(thePath[i][5], thePath[i][6]);
			} else {
				tmpWord = slowMove(thePath[i][5]+((x-thePath[i][5])/4)*1, thePath[i][2]+(y-thePath[i][2])/2.3);
				tmpWord += slowMove(thePath[i][5]+((x-thePath[i][5])/4)*2, thePath[i][2]+(y-thePath[i][2])/2);
				tmpWord += slowMove(thePath[i][5]+((x-thePath[i][5])/4)*3, thePath[i][2]+(y-thePath[i][2])/2.3);
				tmpWord += slowMove(thePath[i][5], thePath[i][6]);
			}
		}
	}
	x = thePath[i][5];
	y = thePath[i][6];
	return tmpWord;
}
function svgS(thePath, i) {
	lastL = "S";
	if (thePath[i][1] > x) {
		if (thePath[i][2] > y) {
			tmpWord = slowMove(thePath[i][1], y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3]-(x+(thePath[i][1]-x)), y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3], thePath[i][4]);
		} else {
			tmpWord = slowMove(thePath[i][1], thePath[i][2]+(y-thePath[i][2])/2);
			tmpWord += slowMove(thePath[i][3]-(x+(thePath[i][1]-x)), y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3], thePath[i][4]);
		}
	} else {
		if (thePath[i][2] > y) {
			tmpWord = slowMove(thePath[i][1], y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3]-(thePath[i][1]+(x-thePath[i][1])), y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3], thePath[i][4]);
		} else {
			tmpWord = slowMove(thePath[i][1], thePath[i][2]+(y-thePath[i][2])/2);
			tmpWord += slowMove(thePath[i][3]-(x-thePath[i][1]), y+(thePath[i][2]-y)/2);
			tmpWord += slowMove(thePath[i][3], thePath[i][4]);
		}
	}
	x = thePath[i][3];
	y = thePath[i][4];
	return tmpWord;
}
function svgQ(thePath, i) {
	lastL = "Q";
	if (thePath[i][2] > y) {
		tmpWord = slowMove(thePath[i][1], y+(thePath[i][2]-y)/2);
		tmpWord += slowMove(thePath[i][3], thePath[i][4]);
		ControlPointY = y+(thePath[i][2]-y)/2;
	} else {
		tmpWord = slowMove(thePath[i][1], thePath[i][2]+(y-thePath[i][2])/2);
		tmpWord += slowMove(thePath[i][3], thePath[i][4]);
		ControlPointY = thePath[i][2]+(y-thePath[i][2])/2;
	}
	x = thePath[i][3];
	y = thePath[i][4];
	ControlPointX = thePath[i][1];
	return tmpWord;
}
function svgT(thePath, i) {
	if (lastL == "Q") {
		if (ControlPointY > y) {
			tmpWord = slowMove(ControlPointX, y-(ControlPointY-y));
			tmpWord += slowMove(thePath[i][1], thePath[i][2]);
		} else {
			tmpWord = slowMove(ControlPointX, ControlPointY-(y-ControlPointY));
			tmpWord += slowMove(thePath[i][1], thePath[i][2]);
		}
	} else {
		tmpWord = slowMove(thePath[i][1], thePath[i][2]);
	}
	lastL = "T";
	x = thePath[i][1];
	y = thePath[i][2];
	return tmpWord;
}
function svgA(thePath, i) {
	lastL = "A";
	x = thePath[i][6];
	y = thePath[i][7];
	return slowMove(thePath[i][6], thePath[i][7]);  //W.I.P.
}
function svgZ(thePath, i) {
	lastL = "A";
	return raiseBit();
}

function raiseBit() {
	return "G01 " + move(x, y) + " Z" + plungeRate + newline;
}

function plunge() {
	return "G01 " + move(x, y) + " Z" + plungeRate + newline;
}

function fastMove(x, y) {
	return "G00 " + move(x, y) + " Z0" + newline;
}

function slowMove(x, y) {
	return "G01 " + move(x, y) + " Z0" + newline;
}

function move(x, y) {
	return "X" + Math.round((((x / slabScale)*100)/5)+650) + " Y" + Math.round((((y / slabScale)*100)/5)-1000);
}
